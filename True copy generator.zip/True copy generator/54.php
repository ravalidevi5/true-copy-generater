<?php
require_once "Classes/PHPExcel.php";
$path="test.xlsx";
$reader= PHPExcel_IOFactory::createReaderForFile($path);
$excel_Obj = $reader->load($path);
 
//Get the last sheet in excel
//$worksheet=$excel_Obj->getActiveSheet();
 
//Get the first sheet in excel
$worksheet=$excel_Obj->getSheet('0');
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C3')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B3')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<td>";
echo "1";
echo "</td>";
echo "<td>";
echo "15CS41T";
echo "</td>";
echo "<td>";
echo "Data Structures using C";
echo "</td>";
echo "<td>";
echo "100";
echo "</td>";
echo "<td>";
echo "35";
echo "</td>";
echo "<td>";
echo $worksheet->getCell('E3')->getValue();
echo "</td>";
echo "<td>";
echo "25";
echo "</td>";
echo "<td>";
echo $worksheet->getCell('O3')->getValue();
echo "</td>";
echo "<td>";
echo "125";
echo "</td>";
echo "<td>";
echo "45";
echo "</td>";
echo "<td>";
echo $worksheet->getCell('Y3')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('AH3')->getValue();
echo "</td>";
echo "<td>";
echo "</td>";
echo "</tr>";

echo "<tr>
<td>2</td>
<td>15CS42T</td>
<td>OOP with java</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F3')->getValue();
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('P3')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('Z3')->getValue();
echo "</td>
<td>";

echo "</td>
</tr>";

echo "<tr>
<td>3</td>
<td>15CS43T</td>
<td>operating System</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G3')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('Q3')->getValue();
echo "</td>
<td>125</td>
<td>45</td>
<td>";
echo $worksheet->getCell('AA3')->getValue();
echo "</td>
<td>";

echo "</td>
</tr>

<tr>
<td>4</td>
<td>15CS44T</td>
<td>PE and IC</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H3')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('R3')->getValue();
echo "</td>
<td>125</td>
<td>45</td>
<td>";
echo $worksheet->getCell('AB3')->getValue();
echo "</td>";
echo $worksheet->getCell('A3')->getValue();
echo "<td>";

echo "</td>
</tr>

<tr>
<td>5</td>
<td>15CS45P</td>
<td>Data Structure Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I3')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('S3')->getValue();
echo "</td>
<td>75</td>
<td>35</td>
<td>";
echo $worksheet->getCell('AC3')->getValue();
echo "</td>
<td>";

echo "</td>

</tr>

<tr>
<td>6</td>
<td>15CS46P</td>
<td>OOP with java Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J3')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('T3')->getValue();
echo "</td>
<td>75</td>
<td>35</td>
<td>";
echo $worksheet->getCell('AD3')->getValue();
echo "</td>
<td>";

echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS47P	</td>
<td>Linux Lab	</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K3')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('U3')->getValue();
echo "</td>
<td>75</td>
<td>35</td>
<td>";
echo $worksheet->getCell('AE3')->getValue();
echo "</td>
<td>";

echo "</td>
</tr>

<tr>
<td>8</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>

</tr>

<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td>
<td>";
echo "215";
echo "</td>
<td>";
echo $worksheet->getCell('N3')->getValue();
echo "</td>
<td>";
echo "175";
echo "</td>
<td>";
echo $worksheet->getCell('V3')->getValue();
echo "</td>
<td>";
echo "725";
echo "</td>
<td>";
echo "285";
echo "</td>
<td>";
echo $worksheet->getCell('AF3')->getValue();
echo "</td>
<td>";
echo $worksheet->getCell('AH3')->getValue();
echo "</td>
<td></td>
</tr>

<tr>
<td colspan='13'>Total in Words:</td>
</tr>

<tr>
<td colspan='13'>Result:</td>
</tr>

<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>

<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
</tr>

<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td>50</td>
<td>20</td>
<td>";
echo $worksheet->getCell('AJ3')->getValue();
echo "</td>
<td></td>
<td></td>
<td>50</td>
<td>20</td>
<td>";
echo $worksheet->getCell('AL3')->getValue();
echo "</td>
<td>";
echo $worksheet->getCell('AH3')->getValue();
echo "</td>
<td></td>
</tr>

<tr>
<td>2</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>

</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";

?>
