<?php
require_once "Classes/PHPExcel.php";
$path="test.xlsx";
$reader= PHPExcel_IOFactory::createReaderForFile($path);
$excel_Obj = $reader->load($path);
 
//Get the last sheet in excel
//$worksheet=$excel_Obj->getActiveSheet();
 
//Get the first sheet in excel
$worksheet=$excel_Obj->getSheet('0');
$reg=$_POST["ureg"];
if($reg==$worksheet->getCell('B1')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C1')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B1')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<td>";
echo "1";
echo "</td>";
echo "<td>";
echo "15CS51T";
echo "</td>";
echo "<td>";
echo "Software Engineering";
echo "</td>";
echo "<td>";
echo "100";
echo "</td>";
echo "<td>";
echo "35";
echo "</td>";
echo "<td>";
echo $worksheet->getCell('E1')->getValue();
echo "</td>";
echo "<td>";
echo "25";
echo "</td>";
echo "<td>";
echo $worksheet->getCell('N1')->getValue();
echo "</td>";
echo "<td>";
echo "125";
echo "</td>";
echo "<td>";
echo "45";
echo "</td>";
echo "<td>";
echo $worksheet->getCell('E1')->getValue() + $worksheet->getCell('N1')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X1')->getValue();
echo "</td>";
echo "<td>";
echo "</td>";
echo "</tr>";

echo "<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F1')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O1')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F1')->getValue() + $worksheet->getCell('O1')->getValue();
echo "</td>
<td>";

echo "</td>
</tr>";

echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G1')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('P1')->getValue();
echo "</td>
<td>125</td>
<td>45</td>
<td>";
echo $worksheet->getCell('G1')->getValue() + $worksheet->getCell('P1')->getValue();
echo "</td>
<td>";

echo "</td>
</tr>

<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H1')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('Q1')->getValue();
echo "</td>
<td>125</td>
<td>45</td>
<td>";
echo $worksheet->getCell('H1')->getValue()+ $worksheet->getCell('Q1')->getValue();
echo "</td>";
echo "<td>";

echo "</td>
</tr>

<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I1')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('R1')->getValue();
echo "</td>
<td>75</td>
<td>35</td>
<td>";
echo $worksheet->getCell('I1')->getValue()+ $worksheet->getCell('R1')->getValue();
echo "</td>
<td>";

echo "</td>

</tr>

<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J1')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('S1')->getValue();
echo "</td>
<td>75</td>
<td>35</td>
<td>";
echo $worksheet->getCell('J1')->getValue()+ $worksheet->getCell('S1')->getValue();
echo "</td>
<td>";

echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K1')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('T1')->getValue();
echo "</td>
<td>75</td>
<td>35</td>
<td>";
echo $worksheet->getCell('K1')->getValue()+ $worksheet->getCell('T1')->getValue();
echo "</td>
<td>";

echo "</td>
</tr>

<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>

</tr>

<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td>
<td>";
echo "215";
echo "</td>
<td>";
echo $worksheet->getCell('M1')->getValue();
echo "</td>
<td>";
echo "175";
echo "</td>
<td>";
echo $worksheet->getCell('V1')->getValue();
echo "</td>
<td>";
echo "725";
echo "</td>
<td>";
echo "285";
echo "</td>
<td>";
echo $worksheet->getCell('W1')->getValue();
echo "</td>
<td>";
echo $worksheet->getCell('X1')->getValue();
echo "</td>
<td></td>
</tr>

<tr>
<td colspan='13'>Total in Words:</td>
</tr>

<tr>
<td colspan='13'>Result:</td>
</tr>

<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>

<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
</tr>

<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td>
<td></td>
<td>";

echo "</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>";

echo "</td>
<td>";

echo "</td>
<td></td>
</tr>

<tr>
<td>2</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>

</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B2')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C2')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B2')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<td>";
echo "1";
echo "</td>";
echo "<td>";
echo "15CS51T";
echo "</td>";
echo "<td>";
echo "Software Engineering";
echo "</td>";
echo "<td>";
echo "100";
echo "</td>";
echo "<td>";
echo "35";
echo "</td>";
echo "<td>";
echo $worksheet->getCell('E2')->getValue();
echo "</td>";
echo "<td>";
echo "25";
echo "</td>";
echo "<td>";
echo $worksheet->getCell('N2')->getValue();
echo "</td>";
echo "<td>";
echo "125";
echo "</td>";
echo "<td>";
echo "45";
echo "</td>";
echo "<td>";
echo $worksheet->getCell('E2')->getValue() + $worksheet->getCell('N2')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X2')->getValue();
echo "</td>";
echo "<td>";
echo "</td>";
echo "</tr>";

echo "<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F2')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O2')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F2')->getValue() + $worksheet->getCell('O2')->getValue();
echo "</td>
<td>";

echo "</td>
</tr>";

echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G2')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('P2')->getValue();
echo "</td>
<td>125</td>
<td>45</td>
<td>";
echo $worksheet->getCell('G2')->getValue() + $worksheet->getCell('P2')->getValue();
echo "</td>
<td>";

echo "</td>
</tr>

<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H2')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('Q2')->getValue();
echo "</td>
<td>125</td>
<td>45</td>
<td>";
echo $worksheet->getCell('H2')->getValue()+ $worksheet->getCell('Q2')->getValue();
echo "</td>";
echo "<td>";

echo "</td>
</tr>

<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I2')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('R2')->getValue();
echo "</td>
<td>75</td>
<td>35</td>
<td>";
echo $worksheet->getCell('I2')->getValue()+ $worksheet->getCell('R2')->getValue();
echo "</td>
<td>";

echo "</td>

</tr>

<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J2')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('S2')->getValue();
echo "</td>
<td>75</td>
<td>35</td>
<td>";
echo $worksheet->getCell('J2')->getValue()+ $worksheet->getCell('S2')->getValue();
echo "</td>
<td>";

echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K2')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('T2')->getValue();
echo "</td>
<td>75</td>
<td>35</td>
<td>";
echo $worksheet->getCell('K2')->getValue()+ $worksheet->getCell('T2')->getValue();
echo "</td>
<td>";

echo "</td>
</tr>

<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>

</tr>

<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td>
<td>";
echo "215";
echo "</td>
<td>";
echo $worksheet->getCell('M2')->getValue();
echo "</td>
<td>";
echo "175";
echo "</td>
<td>";
echo $worksheet->getCell('V2')->getValue();
echo "</td>
<td>";
echo "725";
echo "</td>
<td>";
echo "285";
echo "</td>
<td>";
echo $worksheet->getCell('W2')->getValue();
echo "</td>
<td>";
echo $worksheet->getCell('X2')->getValue();
echo "</td>
<td></td>
</tr>

<tr>
<td colspan='13'>Total in Words:</td>
</tr>

<tr>
<td colspan='13'>Result:</td>
</tr>

<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>

<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
</tr>

<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td>
<td></td>
<td>";

echo "</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>";

echo "</td>
<td>";

echo "</td>
<td></td>
</tr>

<tr>
<td>2</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>

</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B3')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C3')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B3')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<td>";
echo "1";
echo "</td>";
echo "<td>";
echo "15CS51T";
echo "</td>";
echo "<td>";
echo "Software Engineering";
echo "</td>";
echo "<td>";
echo "100";
echo "</td>";
echo "<td>";
echo "35";
echo "</td>";
echo "<td>";
echo $worksheet->getCell('E3')->getValue();
echo "</td>";
echo "<td>";
echo "25";
echo "</td>";
echo "<td>";
echo $worksheet->getCell('N3')->getValue();
echo "</td>";
echo "<td>";
echo "125";
echo "</td>";
echo "<td>";
echo "45";
echo "</td>";
echo "<td>";
echo $worksheet->getCell('E3')->getValue() + $worksheet->getCell('N3')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X3')->getValue();
echo "</td>";
echo "<td>";
echo "</td>";
echo "</tr>";

echo "<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F3')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O3')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F3')->getValue() + $worksheet->getCell('O3')->getValue();
echo "</td>
<td>";

echo "</td>
</tr>";

echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G3')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('P3')->getValue();
echo "</td>
<td>125</td>
<td>45</td>
<td>";
echo $worksheet->getCell('G3')->getValue() + $worksheet->getCell('P3')->getValue();
echo "</td>
<td>";

echo "</td>
</tr>

<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H3')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('Q3')->getValue();
echo "</td>
<td>125</td>
<td>45</td>
<td>";
echo $worksheet->getCell('H3')->getValue()+ $worksheet->getCell('Q3')->getValue();
echo "</td>";
echo "<td>";

echo "</td>
</tr>

<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I3')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('R3')->getValue();
echo "</td>
<td>75</td>
<td>35</td>
<td>";
echo $worksheet->getCell('I3')->getValue()+ $worksheet->getCell('R3')->getValue();
echo "</td>
<td>";

echo "</td>

</tr>

<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J3')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('S3')->getValue();
echo "</td>
<td>75</td>
<td>35</td>
<td>";
echo $worksheet->getCell('J3')->getValue()+ $worksheet->getCell('S3')->getValue();
echo "</td>
<td>";

echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K3')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('T3')->getValue();
echo "</td>
<td>75</td>
<td>35</td>
<td>";
echo $worksheet->getCell('K3')->getValue()+ $worksheet->getCell('T3')->getValue();
echo "</td>
<td>";

echo "</td>
</tr>

<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>

</tr>

<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td>
<td>";
echo "215";
echo "</td>
<td>";
echo $worksheet->getCell('M3')->getValue();
echo "</td>
<td>";
echo "175";
echo "</td>
<td>";
echo $worksheet->getCell('V3')->getValue();
echo "</td>
<td>";
echo "725";
echo "</td>
<td>";
echo "285";
echo "</td>
<td>";
echo $worksheet->getCell('W3')->getValue();
echo "</td>
<td>";
echo $worksheet->getCell('X3')->getValue();
echo "</td>
<td></td>
</tr>

<tr>
<td colspan='13'>Total in Words:</td>
</tr>

<tr>
<td colspan='13'>Result:</td>
</tr>

<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>

<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
</tr>

<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td>
<td></td>
<td>";

echo "</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>";

echo "</td>
<td>";

echo "</td>
<td></td>
</tr>

<tr>
<td>2</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>

</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";

}
else if($reg==$worksheet->getCell('B4')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C4')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B4')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<td>";
echo "1";
echo "</td>";
echo "<td>";
echo "15CS51T";
echo "</td>";
echo "<td>";
echo "Software Engineering";
echo "</td>";
echo "<td>";
echo "100";
echo "</td>";
echo "<td>";
echo "35";
echo "</td>";
echo "<td>";
echo $worksheet->getCell('E4')->getValue();
echo "</td>";
echo "<td>";
echo "25";
echo "</td>";
echo "<td>";
echo $worksheet->getCell('N4')->getValue();
echo "</td>";
echo "<td>";
echo "125";
echo "</td>";
echo "<td>";
echo "45";
echo "</td>";
echo "<td>";
echo 900
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X4')->getValue();
echo "</td>";
echo "<td>";
echo "</td>";
echo "</tr>";

echo "<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F4')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O4')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F4')->getValue() + $worksheet->getCell('O4')->getValue();
echo "</td>
<td>";

echo "</td>
</tr>";

echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G4')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('P4')->getValue();
echo "</td>
<td>125</td>
<td>45</td>
<td>";
echo $worksheet->getCell('G4')->getValue() + $worksheet->getCell('P4')->getValue();
echo "</td>
<td>";

echo "</td>
</tr>

<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H3')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('Q4')->getValue();
echo "</td>
<td>125</td>
<td>45</td>
<td>";
echo $worksheet->getCell('H4')->getValue()+ $worksheet->getCell('Q4')->getValue();
echo "</td>";
echo "<td>";

echo "</td>
</tr>

<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I4')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('R4')->getValue();
echo "</td>
<td>75</td>
<td>35</td>
<td>";
echo $worksheet->getCell('I4')->getValue()+ $worksheet->getCell('R4')->getValue();
echo "</td>
<td>";

echo "</td>

</tr>

<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J4')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('S4')->getValue();
echo "</td>
<td>75</td>
<td>35</td>
<td>";
echo $worksheet->getCell('J4')->getValue()+ $worksheet->getCell('S4')->getValue();
echo "</td>
<td>";

echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K4')->getValue();
echo "</td>
<td>25</td>
<td>";
echo $worksheet->getCell('T4')->getValue();
echo "</td>
<td>75</td>
<td>35</td>
<td>";
echo $worksheet->getCell('K4')->getValue()+ $worksheet->getCell('T4')->getValue();
echo "</td>
<td>";

echo "</td>
</tr>

<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>
<td>";
echo "</td>

</tr>

<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td>
<td>";
echo "215";
echo "</td>
<td>";
echo $worksheet->getCell('M4')->getValue();
echo "</td>
<td>";
echo "175";
echo "</td>
<td>";
echo $worksheet->getCell('V4')->getValue();
echo "</td>
<td>";
echo "725";
echo "</td>
<td>";
echo "285";
echo "</td>
<td>";
echo $worksheet->getCell('W4')->getValue();
echo "</td>
<td>";
echo $worksheet->getCell('X4')->getValue();
echo "</td>
<td></td>
</tr>

<tr>
<td colspan='13'>Total in Words:</td>
</tr>

<tr>
<td colspan='13'>Result:</td>
</tr>

<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>

<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
</tr>

<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td>
<td></td>
<td>";

echo "</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>";

echo "</td>
<td>";

echo "</td>
<td></td>
</tr>

<tr>
<td>2</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>

</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B5')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C5')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B5')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E5')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N5')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E5')->getValue() + $worksheet->getCell('N5')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X5')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F5')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O5')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F5')->getValue() + $worksheet->getCell('O5')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G5')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P5')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G5')->getValue() + $worksheet->getCell('P5')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H5')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q5')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H5')->getValue()+ $worksheet->getCell('Q5')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I5')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R5')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I5')->getValue()+ $worksheet->getCell('R5')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J5')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S5')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J5')->getValue()+ $worksheet->getCell('S5')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K5')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T5')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K5')->getValue()+ $worksheet->getCell('T5')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M5')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V5')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W5')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X5')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B6')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C6')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B6')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E6')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N6')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E5')->getValue() + $worksheet->getCell('N6')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X6')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F6')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O6')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F6')->getValue() + $worksheet->getCell('O6')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G6')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P6')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G6')->getValue() + $worksheet->getCell('P6')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H6')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q6')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H6')->getValue()+ $worksheet->getCell('Q6')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I6')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R6')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I6')->getValue()+ $worksheet->getCell('R6')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J6')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S6')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J6')->getValue()+ $worksheet->getCell('S6')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K6')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T6')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K6')->getValue()+ $worksheet->getCell('T6')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M6')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V6')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W6')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X6')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B7')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C7')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B7')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E7')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N7')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E7')->getValue() + $worksheet->getCell('N7')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X7')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F7')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O7')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F7')->getValue() + $worksheet->getCell('O7')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G7')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P7')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G7')->getValue() + $worksheet->getCell('P7')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H7')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q7')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H7')->getValue()+ $worksheet->getCell('Q7')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I7')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R7')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I7')->getValue()+ $worksheet->getCell('R7')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J7')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S7')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J7')->getValue()+ $worksheet->getCell('S7')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K7')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T7')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K7')->getValue()+ $worksheet->getCell('T7')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M7')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V7')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W7')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X7')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B8')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C8')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B8')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E8')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N8')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E8')->getValue() + $worksheet->getCell('N8')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X8')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F8')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O8')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F8')->getValue() + $worksheet->getCell('O8')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G8')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P8')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G8')->getValue() + $worksheet->getCell('P8')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H8')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q8')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H8')->getValue()+ $worksheet->getCell('Q8')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I8')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R8')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I8')->getValue()+ $worksheet->getCell('R8')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J8')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S8')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J8')->getValue()+ $worksheet->getCell('S8')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K8')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T8')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K8')->getValue()+ $worksheet->getCell('T8')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M8')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V8')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W8')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X8')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B9')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C9')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B9')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E9')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N9')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E9')->getValue() + $worksheet->getCell('N9')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X9')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F9')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O9')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F9')->getValue() + $worksheet->getCell('O9')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G9')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P9')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G9')->getValue() + $worksheet->getCell('P9')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H9')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q9')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H9')->getValue()+ $worksheet->getCell('Q9')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I9')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R9')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I9')->getValue()+ $worksheet->getCell('R9')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J9')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S9')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J9')->getValue()+ $worksheet->getCell('S9')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K9')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T9')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K9')->getValue()+ $worksheet->getCell('T9')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M9')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V9')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W9')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X9')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B10')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C10')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B10')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E10')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N10')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E10')->getValue() + $worksheet->getCell('N10')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X10')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F10')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O10')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F10')->getValue() + $worksheet->getCell('O10')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G10')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P10')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G10')->getValue() + $worksheet->getCell('P10')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H10')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q10')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H10')->getValue()+ $worksheet->getCell('Q10')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I10')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R10')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I10')->getValue()+ $worksheet->getCell('R10')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J10')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S10')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J10')->getValue()+ $worksheet->getCell('S10')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K10')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T10')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K10')->getValue()+ $worksheet->getCell('T10')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M10')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V10')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W10')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X10')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B11')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C11')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B11')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E11')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N11')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E11')->getValue() + $worksheet->getCell('N11')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X11')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F11')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O11')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F11')->getValue() + $worksheet->getCell('O11')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G11')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P11')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G11')->getValue() + $worksheet->getCell('P11')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H11')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q11')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H11')->getValue()+ $worksheet->getCell('Q11')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I11')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R11')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I11')->getValue()+ $worksheet->getCell('R11')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J11')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S11')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J11')->getValue()+ $worksheet->getCell('S11')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K11')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T11')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K11')->getValue()+ $worksheet->getCell('T11')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M11')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V11')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W11')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X11')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B12')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C12')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B12')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E12')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N12')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E12')->getValue() + $worksheet->getCell('N12')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X12')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F12')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O12')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F12')->getValue() + $worksheet->getCell('O12')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G12')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P12')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G12')->getValue() + $worksheet->getCell('P12')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H12')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q12')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H12')->getValue()+ $worksheet->getCell('Q12')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I12')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R12')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I12')->getValue()+ $worksheet->getCell('R12')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J12')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S12')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J12')->getValue()+ $worksheet->getCell('S12')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K12')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T12')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K12')->getValue()+ $worksheet->getCell('T12')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M12')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V12')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W12')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X12')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B13')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C13')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B13')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E13')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N13')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E13')->getValue() + $worksheet->getCell('N13')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X13')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F13')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O13')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F13')->getValue() + $worksheet->getCell('O13')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G13')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P13')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G13')->getValue() + $worksheet->getCell('P13')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H13')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q13')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H13')->getValue()+ $worksheet->getCell('Q13')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I13')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R13')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I13')->getValue()+ $worksheet->getCell('R13')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J13')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S13')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J13')->getValue()+ $worksheet->getCell('S13')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K13')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T13')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K13')->getValue()+ $worksheet->getCell('T13')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M13')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V13')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W13')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X13')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B14')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C14')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B14')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E14')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N14')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E14')->getValue() + $worksheet->getCell('N14')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X14')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F14')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O14')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F14')->getValue() + $worksheet->getCell('O14')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G14')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P14')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G14')->getValue() + $worksheet->getCell('P14')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H14')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q14')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H14')->getValue()+ $worksheet->getCell('Q14')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I14')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R14')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I14')->getValue()+ $worksheet->getCell('R14')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J14')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S14')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J14')->getValue()+ $worksheet->getCell('S14')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K14')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T14')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K14')->getValue()+ $worksheet->getCell('T14')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M14')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V14')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W14')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X14')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B15')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C15')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B15')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E15')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N15')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E15')->getValue() + $worksheet->getCell('N15')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X15')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F15')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O15')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F15')->getValue() + $worksheet->getCell('O15')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G15')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P15')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G15')->getValue() + $worksheet->getCell('P15')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H15')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q15')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H15')->getValue()+ $worksheet->getCell('Q15')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I15')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R15')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I15')->getValue()+ $worksheet->getCell('R15')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J15')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S15')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J15')->getValue()+ $worksheet->getCell('S15')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K15')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T15')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K15')->getValue()+ $worksheet->getCell('T15')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M15')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V15')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W15')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X15')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B16')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C16')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B16')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E16')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N16')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E16')->getValue() + $worksheet->getCell('N16')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X16')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F16')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O16')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F16')->getValue() + $worksheet->getCell('O16')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G16')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P16')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G16')->getValue() + $worksheet->getCell('P16')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H16')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q16')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H16')->getValue()+ $worksheet->getCell('Q16')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I16')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R16')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I16')->getValue()+ $worksheet->getCell('R16')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J16')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S16')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J16')->getValue()+ $worksheet->getCell('S16')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K16')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T16')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K16')->getValue()+ $worksheet->getCell('T16')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M16')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V16')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W16')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X16')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B17')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C17')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B17')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E17')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N17')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E17')->getValue() + $worksheet->getCell('N17')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X17')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F17')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O17')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F17')->getValue() + $worksheet->getCell('O17')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G17')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P17')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G17')->getValue() + $worksheet->getCell('P17')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H17')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q17')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H17')->getValue()+ $worksheet->getCell('Q17')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I17')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R17')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I17')->getValue()+ $worksheet->getCell('R17')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J17')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S17')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J17')->getValue()+ $worksheet->getCell('S17')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K17')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T17')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K17')->getValue()+ $worksheet->getCell('T17')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M17')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V17')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W17')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X17')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B18')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C18')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B18')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E18')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N18')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E18')->getValue() + $worksheet->getCell('N18')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X18')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F18')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O18')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F18')->getValue() + $worksheet->getCell('O18')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G18')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P18')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G18')->getValue() + $worksheet->getCell('P18')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H18')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q18')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H18')->getValue()+ $worksheet->getCell('Q18')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I18')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R18')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I18')->getValue()+ $worksheet->getCell('R18')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J18')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S18')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J18')->getValue()+ $worksheet->getCell('S18')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K18')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T18')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K18')->getValue()+ $worksheet->getCell('T18')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M18')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V18')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W18')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X18')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B19')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C19')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B19')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E19')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N19')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E19')->getValue() + $worksheet->getCell('N19')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X19')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F19')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O19')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F19')->getValue() + $worksheet->getCell('O19')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G19')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P19')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G19')->getValue() + $worksheet->getCell('P19')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H19')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q19')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H19')->getValue()+ $worksheet->getCell('Q19')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I19')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R19')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I19')->getValue()+ $worksheet->getCell('R19')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J19')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S19')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J19')->getValue()+ $worksheet->getCell('S19')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K19')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T19')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K19')->getValue()+ $worksheet->getCell('T19')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M19')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V19')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W19')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X19')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B20')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C20')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B20')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E20')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N20')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E20')->getValue() + $worksheet->getCell('N20')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X20')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F20')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O20')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F20')->getValue() + $worksheet->getCell('O20')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G20')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P20')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G20')->getValue() + $worksheet->getCell('P20')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H20')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q20')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H20')->getValue()+ $worksheet->getCell('Q20')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I20')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R20')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I20')->getValue()+ $worksheet->getCell('R20')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J20')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S20')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J20')->getValue()+ $worksheet->getCell('S20')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K20')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T20')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K20')->getValue()+ $worksheet->getCell('T20')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M20')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V20')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W20')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X20')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B21')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C21')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B21')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E21')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N21')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E21')->getValue() + $worksheet->getCell('N21')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X21')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F21')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O21')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F21')->getValue() + $worksheet->getCell('O21')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G21')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P21')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G21')->getValue() + $worksheet->getCell('P21')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H21')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q21')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H21')->getValue()+ $worksheet->getCell('Q21')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I21')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R21')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I21')->getValue()+ $worksheet->getCell('R21')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J21')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S21')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J21')->getValue()+ $worksheet->getCell('S21')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K21')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T21')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K21')->getValue()+ $worksheet->getCell('T21')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M21')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V21')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W21')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X21')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B22')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C22')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B22')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E22')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N22')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E22')->getValue() + $worksheet->getCell('N22')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X22')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F22')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O22')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F22')->getValue() + $worksheet->getCell('O22')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G22')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P22')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G22')->getValue() + $worksheet->getCell('P22')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H22')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q22')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H22')->getValue()+ $worksheet->getCell('Q22')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I22')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R22')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I22')->getValue()+ $worksheet->getCell('R22')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J22')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S22')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J22')->getValue()+ $worksheet->getCell('S22')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K22')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T22')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K22')->getValue()+ $worksheet->getCell('T22')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M22')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V22')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W22')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X22')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B23')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C23')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B23')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E23')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N23')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E23')->getValue() + $worksheet->getCell('N23')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X23')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F23')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O23')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F23')->getValue() + $worksheet->getCell('O23')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G23')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P23')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G23')->getValue() + $worksheet->getCell('P23')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H23')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q23')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H23')->getValue()+ $worksheet->getCell('Q23')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I23')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R23')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I23')->getValue()+ $worksheet->getCell('R23')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J23')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S23')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J23')->getValue()+ $worksheet->getCell('S23')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K23')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T23')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K23')->getValue()+ $worksheet->getCell('T23')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M23')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V23')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W23')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X23')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B24')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C24')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B24')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E24')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N24')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E24')->getValue() + $worksheet->getCell('N24')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X24')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F24')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O24')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F24')->getValue() + $worksheet->getCell('O24')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G24')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P24')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G24')->getValue() + $worksheet->getCell('P24')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H24')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q24')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H24')->getValue()+ $worksheet->getCell('Q24')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I24')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R24')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I24')->getValue()+ $worksheet->getCell('R24')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J24')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S24')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J24')->getValue()+ $worksheet->getCell('S24')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K24')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T24')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K24')->getValue()+ $worksheet->getCell('T24')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M24')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V24')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W24')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X24')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B25')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C25')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B25')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E25')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N25')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E25')->getValue() + $worksheet->getCell('N25')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X25')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F25')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O25')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F25')->getValue() + $worksheet->getCell('O25')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G25')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P25')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G25')->getValue() + $worksheet->getCell('P25')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H25')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q25')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H25')->getValue()+ $worksheet->getCell('Q25')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I25')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R25')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I25')->getValue()+ $worksheet->getCell('R25')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J25')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S25')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J25')->getValue()+ $worksheet->getCell('S25')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K25')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T25')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K25')->getValue()+ $worksheet->getCell('T25')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M25')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V25')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W25')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X25')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B26')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C26')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B26')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E26')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N26')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E26')->getValue() + $worksheet->getCell('N26')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X26')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F26')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O26')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F26')->getValue() + $worksheet->getCell('O26')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G26')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P26')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G26')->getValue() + $worksheet->getCell('P26')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H26')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q26')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H26')->getValue()+ $worksheet->getCell('Q26')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I26')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R26')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I26')->getValue()+ $worksheet->getCell('R26')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J26')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S26')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J26')->getValue()+ $worksheet->getCell('S26')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K26')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T26')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K26')->getValue()+ $worksheet->getCell('T26')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M26')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V26')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W26')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X26')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B27')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C27')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B27')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E27')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N27')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E27')->getValue() + $worksheet->getCell('N27')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X27')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F27')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O27')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F27')->getValue() + $worksheet->getCell('O27')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G27')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P27')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G27')->getValue() + $worksheet->getCell('P27')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H27')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q27')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H27')->getValue()+ $worksheet->getCell('Q27')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I27')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R27')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I27')->getValue()+ $worksheet->getCell('R27')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J27')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S27')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J27')->getValue()+ $worksheet->getCell('S27')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K27')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T27')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K27')->getValue()+ $worksheet->getCell('T27')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M27')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V27')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W27')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X27')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B28')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C28')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B28')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E28')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N28')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E28')->getValue() + $worksheet->getCell('N28')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X28')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F28')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O28')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F28')->getValue() + $worksheet->getCell('O28')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G28')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P28')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G28')->getValue() + $worksheet->getCell('P28')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H28')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q28')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H28')->getValue()+ $worksheet->getCell('Q28')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I28')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R28')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I28')->getValue()+ $worksheet->getCell('R28')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J28')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S28')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J28')->getValue()+ $worksheet->getCell('S28')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K28')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T28')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K28')->getValue()+ $worksheet->getCell('T28')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M28')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V28')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W28')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X28')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B29')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C29')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B29')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E29')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N29')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E29')->getValue() + $worksheet->getCell('N29')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X29')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F29')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O29')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F29')->getValue() + $worksheet->getCell('O29')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G29')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P29')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G29')->getValue() + $worksheet->getCell('P29')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H29')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q29')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H29')->getValue()+ $worksheet->getCell('Q29')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I29')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R29')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I29')->getValue()+ $worksheet->getCell('R29')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J29')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S29')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J29')->getValue()+ $worksheet->getCell('S29')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K29')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T29')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K29')->getValue()+ $worksheet->getCell('T29')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M29')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V29')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W29')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X29')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B30')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C30')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B30')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E30')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N30')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E30')->getValue() + $worksheet->getCell('N30')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X30')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F30')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O30')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F30')->getValue() + $worksheet->getCell('O30')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G30')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P30')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G30')->getValue() + $worksheet->getCell('P30')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H30')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q30')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H30')->getValue()+ $worksheet->getCell('Q30')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I30')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R30')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I30')->getValue()+ $worksheet->getCell('R30')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J30')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S30')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J30')->getValue()+ $worksheet->getCell('S30')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K30')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T30')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K30')->getValue()+ $worksheet->getCell('T30')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M30')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V30')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W30')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X30')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B31')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C31')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B31')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E31')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N31')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E31')->getValue() + $worksheet->getCell('N31')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X31')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F31')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O31')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F31')->getValue() + $worksheet->getCell('O31')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G31')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P31')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G31')->getValue() + $worksheet->getCell('P31')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H31')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q31')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H31')->getValue()+ $worksheet->getCell('Q31')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I31')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R31')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I31')->getValue()+ $worksheet->getCell('R31')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J31')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S31')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J31')->getValue()+ $worksheet->getCell('S31')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K31')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T31')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K31')->getValue()+ $worksheet->getCell('T31')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M31')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V31')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W31')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X31')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B32')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C32')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B32')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E32')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N32')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E32')->getValue() + $worksheet->getCell('N32')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X32')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F32')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O32')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F32')->getValue() + $worksheet->getCell('O32')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G32')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P32')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G32')->getValue() + $worksheet->getCell('P32')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H32')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q32')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H32')->getValue()+ $worksheet->getCell('Q32')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I32')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R32')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I32')->getValue()+ $worksheet->getCell('R32')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J32')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S32')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J32')->getValue()+ $worksheet->getCell('S32')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K32')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T32')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K32')->getValue()+ $worksheet->getCell('T32')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M32')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V32')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W32')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X32')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B33')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C33')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B33')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E33')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N33')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E33')->getValue() + $worksheet->getCell('N33')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X33')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F33')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O33')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F33')->getValue() + $worksheet->getCell('O33')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G33')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P33')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G33')->getValue() + $worksheet->getCell('P33')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H33')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q33')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H33')->getValue()+ $worksheet->getCell('Q33')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I33')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R33')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I33')->getValue()+ $worksheet->getCell('R33')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J33')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S33')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J33')->getValue()+ $worksheet->getCell('S33')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K33')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T33')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K33')->getValue()+ $worksheet->getCell('T33')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M33')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V33')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W33')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X33')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B34')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C34')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B34')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E34')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N34')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E34')->getValue() + $worksheet->getCell('N34')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X34')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F34')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O34')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F34')->getValue() + $worksheet->getCell('O34')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G34')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P34')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G34')->getValue() + $worksheet->getCell('P34')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H34')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q34')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H34')->getValue()+ $worksheet->getCell('Q34')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I34')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R34')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I34')->getValue()+ $worksheet->getCell('R34')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J34')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S34')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J34')->getValue()+ $worksheet->getCell('S34')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K34')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T34')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K34')->getValue()+ $worksheet->getCell('T34')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M34')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V34')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W34')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X34')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B35')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C35')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B35')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E35')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N35')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E35')->getValue() + $worksheet->getCell('N35')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X35')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F35')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O35')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F35')->getValue() + $worksheet->getCell('O35')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G35')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P35')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G35')->getValue() + $worksheet->getCell('P35')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H35')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q35')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H35')->getValue()+ $worksheet->getCell('Q35')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I35')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R35')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I35')->getValue()+ $worksheet->getCell('R35')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J35')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S35')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J35')->getValue()+ $worksheet->getCell('S35')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K35')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T35')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K35')->getValue()+ $worksheet->getCell('T35')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M35')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V35')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W35')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X35')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B36')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C36')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B36')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E36')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N36')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E36')->getValue() + $worksheet->getCell('N36')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X36')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F36')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O36')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F36')->getValue() + $worksheet->getCell('O36')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G36')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P36')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G36')->getValue() + $worksheet->getCell('P36')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H36')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q36')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H36')->getValue()+ $worksheet->getCell('Q36')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I36')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R36')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I36')->getValue()+ $worksheet->getCell('R36')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J36')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S36')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J36')->getValue()+ $worksheet->getCell('S36')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K36')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T36')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K36')->getValue()+ $worksheet->getCell('T36')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M36')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V36')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W36')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X36')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else if($reg==$worksheet->getCell('B37')->getValue())
{
echo "<h5><u><font size=4>104</font></u><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ಕರ್ನಾಟಕ ಸರ್ಕಾರ</font></h5>
<h5><font size=4>GPT.B &nbsp; No.:</font><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;GOVERNMENT OF KARNATAKA</font></h5>
<h3><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;ತಾಂತ್ರಿಕ ಶಿಕ್ಷಣ ಇಲಾಖೆ, ಬೆಂಗಳೂರು</font></h3>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;DEPARTMENT OF TECHNICAL EDUCATION, BANGALORE</font></h1>
<h2><font size=4>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;ತಾಂತ್ರಿಕ ಪರೀಕ್ಷೆ ಮಂಡಳಿ  </font></h2>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;BOARD OF TECHNICAL EXAMINATIONS</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;PROVISIONAL MARKS CARD</font></h1>
<h1><font size=4>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;&emsp;<u>&emsp;4th&emsp;</u>SEMESTER EXAMINATIONS MAY/NOV.20</h1>
<u>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</u>
<h3>Programme&nbsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&nbsp;<font size=5>Computer Science and Engg</font>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date of Result:</h3><h3>Name of the Candidate&emsp;:";
echo $worksheet->getCell('C37')->getValue();
echo "</h3>
<h3>Father's Name&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;:</h3>
<h3>Mother's Name&nbsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Reg.No:";
echo $worksheet->getCell('B37')->getValue();
echo "</h3>
<h3>Name of the Institution&emsp;:<font size=4.5>GOVERNMENT POLYTECHNIC, BALLARI(104)</font></h3>";

echo "<table border='2'>";
echo "<tr>";
echo "<th rowspan='2'>";
echo "Sl.No. ";
echo "</th>";
echo "<th rowspan='2'>";
echo "QP Code &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course Title &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
echo " </th>";
echo "<th colspan='3'>";
echo "Semester End </br>Examination(SSE)";
echo "</th>";
echo "<th colspan='2'>";
echo "Contineous</br> Internal</br> evaluation(CIE)";
echo "</th>";
echo "<th colspan='3'>";
echo "Total Marks";
echo "</th>";
echo "<th rowspan='2'>";
echo "Course</br> Results</br> 9";
echo "</th>";
echo "<th rowspan='2'>";
echo "Credit</br> ";
echo "Score </br>10";
echo "</th>";
echo "</tr>";

echo "<tr>";
echo "<th>";
echo "Max.</br> Marks </br>1";
echo "</th>";
echo "<th>";
echo "Min.</br> Marks </br>2";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained</br> 3";
echo "</th>";
echo "<th>";
echo "Max. <br/>Marks </br>4";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>5";
echo "</th>";
echo "<th>";
echo "Max. </br>Marks </br>6";
echo "</th>";
echo "<th>";
echo "Max.</br> Marks </br>7";
echo "</th>";
echo "<th>";
echo "Marks </br>obtained </br>8";
echo "</th>
</tr>
<tr>
<td>1</td>
<td>15CS51T</td>
<td>Software Engineering</td>
<td>100</td><td>35</td><td>";
echo $worksheet->getCell('E37')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('N37')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('E37')->getValue() + $worksheet->getCell('N37')->getValue();
echo "</td>";
echo "<td rowspan='8'>";
echo $worksheet->getCell('X37')->getValue();
echo "</td><td></td>
</tr>
<tr>
<td>2</td>
<td>15CS52T</td>
<td>Web Programming</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('F37')->getValue(); 
echo "</td>
<td>25</td>";
echo "<td>";
echo $worksheet->getCell('O37')->getValue();
echo "</td>
<td>125</td>
<td>45</td>";
echo "<td>";
echo $worksheet->getCell('F37')->getValue() + $worksheet->getCell('O37')->getValue();
echo "</td><td>";
echo "</td>
</tr>";
echo "<tr>
<td>3</td>
<td>15CS53T</td>
<td>Design and Analysis of Algorithms</td>
<td>100</td>
<td>35</td>";
echo "<td>";
echo $worksheet->getCell('G37')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('P37')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('G37')->getValue() + $worksheet->getCell('P37')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>4</td>
<td>15CS54T</td>
<td>Green Computing</td>
<td>100</td>
<td>35</td>
<td>";
echo $worksheet->getCell('H37')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('Q37')->getValue();
echo "</td><td>125</td>
<td>45</td><td>";
echo $worksheet->getCell('H37')->getValue()+ $worksheet->getCell('Q37')->getValue();
echo "</td>";
echo "<td>";
echo "</td>
</tr>
<tr>
<td>5</td>
<td>15CS55P</td>
<td>Web Programming Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('I37')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('R37')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('I37')->getValue()+ $worksheet->getCell('R37')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>6</td>
<td>15CS56P</td>
<td>Design and Analysis of Algorithms Lab</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('J37')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('S37')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('J37')->getValue()+ $worksheet->getCell('S37')->getValue();
echo "</td><td>";
echo "</td>
</tr>

<tr>
<td>7</td>
<td>15CS57P	</td>
<td>Proffessional Practices		</td>
<td>50</td>
<td>25</td>
<td>";
echo $worksheet->getCell('K37')->getValue();
echo "</td><td>25</td><td>";
echo $worksheet->getCell('T37')->getValue();
echo "</td><td>75</td>
<td>35</td><td>";
echo $worksheet->getCell('K37')->getValue()+ $worksheet->getCell('T37')->getValue();
echo "</td><td>";
echo "</td>
</tr>
<tr>
<td>8</td>
<td>15CS58P	</td>
<td>Project Work Phase-1</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td><td>";
echo "</td>
</tr>
<tr>
<th colspan='3'>GRAND TOTAL</th>
<td>";
echo "550";
echo "</td><td>";
echo "215";
echo "</td><td>";
echo $worksheet->getCell('M37')->getValue();
echo "</td><td>";
echo "175";
echo "</td><td>";
echo $worksheet->getCell('V37')->getValue();
echo "</td><td>";
echo "725";
echo "</td><td>";
echo "285";
echo "</td><td>";
echo $worksheet->getCell('W37')->getValue();
echo "</td><td>";
echo $worksheet->getCell('X37')->getValue();
echo "</td>
<td></td>
</tr>
<tr>
<td colspan='13'>Total in Words:</td>
</tr><tr>
<td colspan='13'>Result:</td></tr>
<tr>
<td colspan='13'>&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;Bridge Courses(For Lateral Entry Students Only) & Kannada Course(For all students)</td>
</tr>
<tr>
<td>Sl. No</td>
<td>QP Code</td>
<td>&emsp;&emsp;&ensp;Course Title</td>
<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
</tr>
<tr>
<td>1</td>
<td>15KA4KT</td>
<td>Tantrika kannada 2</td>
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
<tr>
<td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
</tr>
</table>
</br></br></br></br>
<h4>Signature of the Candidate&emsp;&emsp;&emsp;&emsp;Signature of the H.O.D&emsp;&emsp;&emsp;&emsp;&emsp;Signature of the Principal with Insitute seal</h4>";
}
else 
{
	echo "Register Number Not Found ";
}
?>
